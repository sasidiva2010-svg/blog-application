
const express = require("express");
const cors = require("cors");
const db = require("./db");
const authRoutes = require("./routes/authRoutes");
const blogRoutes = require("./routes/blogRoutes");
const app = express();

app.use(cors());
app.use(express.json());

// Home route
app.get("/", (req, res) => {
    res.send("BlogSpace Backend is Running!");
});

// Registration route
app.use("/api/auth", authRoutes);
app.use("/api/blogs", blogRoutes);
app.get("/test", (req, res) => {
    res.send("Test route is working!");
});
console.log("Registration route loaded");

app.listen(5001, () => {
    console.log("Server running on port 5001");
});
