const express = require("express");
const db = require("../db");

const router = express.Router();

// Create Blog API
router.post("/create", (req, res) => {
    const { title, category, content, user_id } = req.body;

    if (!title || !content || !user_id) {
        return res.status(400).json({
            message: "Please fill all required fields"
        });
    }

    const sql = `
        INSERT INTO blogs (title, category, content, user_id)
        VALUES (?, ?, ?, ?)
    `;

    db.query(sql, [title, category, content, user_id], (err, result) => {
        if (err) {
            return res.status(500).json({
                message: "Blog creation failed"
            });
        }

        res.status(201).json({
            message: "Blog created successfully!",
            blogId: result.insertId
        });
    });
});
// Get All Blogs API
router.get("/all", (req, res) => {
    const sql = "SELECT * FROM blogs ORDER BY created_at DESC";

    db.query(sql, (err, results) => {
        if (err) {
            return res.status(500).json({
                message: "Failed to fetch blogs"
            });
        }

        res.json({
            message: "Blogs fetched successfully!",
            blogs: results
        });
    });
});

module.exports = router;