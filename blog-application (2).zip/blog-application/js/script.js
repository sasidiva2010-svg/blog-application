
"use strict";

/* =====================================
   BLOGSPACE - SHARED JAVASCRIPT
   ===================================== */

const BlogSpace = (() => {
    const POSTS_KEY = "blogspace_posts";
    const PROFILE_KEY = "blogspace_demo_profile";

    function getPosts() {
        try {
            const posts = JSON.parse(localStorage.getItem(POSTS_KEY));
            return Array.isArray(posts) ? posts : [];
        } catch (error) {
            console.error("Unable to read blog posts:", error);
            return [];
        }
    }

    function savePosts(posts) {
        try {
            localStorage.setItem(POSTS_KEY, JSON.stringify(posts));
            return true;
        } catch (error) {
            console.error("Unable to save blog posts:", error);
            return false;
        }
    }

    function createElement(tag, text, className) {
        const element = document.createElement(tag);
        element.textContent = text || "";

        if (className) {
            element.className = className;
        }

        return element;
    }

    // HOME PAGE SEARCH
    function initializeHomeSearch() {
        const search = document.getElementById("searchInput");
        const grid = document.getElementById("blogGrid");
        const empty = document.getElementById("noResults");

        if (!search || !grid) return;

        search.addEventListener("input", () => {
            const query = search.value.toLowerCase().trim();
            let count = 0;

            grid.querySelectorAll(".blog-card").forEach(card => {
                const matches = card.textContent
                    .toLowerCase()
                    .includes(query);

                card.hidden = !matches;

                if (matches) count++;
            });

            if (empty) {
                empty.hidden = count !== 0;
            }
        });
    }

    // RENDER HOME POSTS
    function renderHomePosts() {
        const grid = document.getElementById("blogGrid");
        if (!grid) return;

        const posts = getPosts();
        grid.replaceChildren();

        posts.forEach(post => {
            const card = createElement("article", "", "blog-card");

            card.appendChild(createElement(
                "span", post.category || "General", "category"
            ));

            card.appendChild(createElement("h3", post.title));
            card.appendChild(createElement("p", post.description));

            const link = createElement(
                "a", "Read More →", "read-more"
            );

            link.href = "login.html";

            card.appendChild(link);
            grid.appendChild(card);
        });

        initializeHomeSearch();
    }

    // DASHBOARD POSTS
    function renderDashboard() {
        const grid = document.getElementById("postGrid");
        const empty = document.getElementById("empty");
        const search = document.getElementById("search");

        if (!grid || !empty) return;

        const posts = getPosts();
        const query = search ? search.value.toLowerCase().trim() : "";

        const filtered = posts.filter(post =>
            [post.title, post.category, post.content]
                .some(value =>
                    String(value || "").toLowerCase().includes(query)
                )
        );

        grid.replaceChildren();

        empty.hidden = filtered.length !== 0;
        empty.textContent = posts.length
            ? "No matching posts found."
            : "No blog posts yet. Create your first post!";

        filtered.forEach(post => {
            const card = createElement("article", "", "post");

            card.appendChild(createElement(
                "span", post.category || "General", "category"
            ));

            card.appendChild(createElement("h3", post.title));

            const preview = String(post.content || "");

            card.appendChild(createElement(
                "p",
                preview.length > 150
                    ? preview.slice(0, 150) + "..."
                    : preview
            ));

            if (post.date) {
                const time = createElement(
                    "time",
                    new Date(post.date).toLocaleDateString()
                );

                card.appendChild(time);
            }

            const actions = createElement("div", "", "actions");

            const edit = createElement("a", "Edit", "btn");
            edit.href = "create-blog.html?edit=" +
                encodeURIComponent(post.id);

            const remove = createElement(
                "button", "Delete", "btn btn-danger"
            );

            remove.type = "button";

            remove.addEventListener("click", () => {
                if (!confirm("Are you sure you want to delete this post?")) {
                    return;
                }

                const remaining = getPosts().filter(
                    item => String(item.id) !== String(post.id)
                );

                if (savePosts(remaining)) {
                    renderDashboard();
                } else {
                    alert("Unable to save changes.");
                }
            });

            actions.append(edit, remove);
            card.appendChild(actions);
            grid.appendChild(card);
        });
    }

    // PASSWORD SHOW / HIDE
    function initializePasswordToggle() {
        const password = document.getElementById("password");
        const toggle = document.getElementById("togglePassword");

        if (!password || !toggle) return;

        toggle.addEventListener("click", () => {
            const show = password.type === "password";

            password.type = show ? "text" : "password";
            toggle.textContent = show ? "Hide" : "Show";

            toggle.setAttribute("aria-pressed", String(show));

            toggle.setAttribute(
                "aria-label",
                show ? "Hide password" : "Show password"
            );
        });
    }

    // REGISTRATION - BACKEND API
    function initializeRegistration() {
        const form = document.getElementById("registerForm");
        if (!form) return;

        form.addEventListener("submit", async (event) => {
            event.preventDefault();

            if (!form.reportValidity()) return;

            const name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value;
            const confirm = document.getElementById("confirmPassword").value;
            const message = document.getElementById("message");

            if (password !== confirm) {
                message.textContent = "Passwords do not match.";
                message.className = "message error";
                return;
            }

            try {
                const response = await fetch(
                    "http://localhost:5001/api/auth/register",
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            name,
                            email,
                            password
                        })
                    }
                );

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.message);
                }

                localStorage.setItem(
                    PROFILE_KEY,
                    JSON.stringify({ name, email })
                );

                message.textContent = data.message;
                message.className = "message success";

                setTimeout(() => {
                    window.location.href = "login.html";
                }, 1500);

            } catch (error) {
                message.textContent = error.message ||
                    "Server connection failed.";

                message.className = "message error";
            }
        });
    }

    // LOGIN - BACKEND API
    function initializeLogin() {
        const form = document.getElementById("loginForm");
        if (!form) return;

        form.addEventListener("submit", async (event) => {
            event.preventDefault();

            if (!form.reportValidity()) return;

            const email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value;
            const message = document.getElementById("message");

            try {
                const response = await fetch(
                    "http://localhost:5001/api/auth/login",
                    {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            email,
                            password
                        })
                    }
                );

                const data = await response.json();

                if (!response.ok) {
                    throw new Error(data.message);
                }

                sessionStorage.setItem(
                    "blogspace_demo_session",
                    JSON.stringify({
                        name: data.name,
                        email: email,
                        userId: data.userId
                    })
                );

                message.textContent = data.message;
                message.className = "message success";

                window.location.href = "dashboard.html";

            } catch (error) {
                message.textContent = error.message ||
                    "Server connection failed.";

                message.className = "message error";
            }
        });
    }

    // CREATE AND EDIT BLOG
// CREATE AND EDIT BLOG - BACKEND API
function initializeCreateBlog() {
    const form = document.getElementById("blogForm");
    if (!form) return;

    const title = document.getElementById("title");
    const description = document.getElementById("description");
    const category = document.getElementById("category");
    const content = document.getElementById("content");
    const imageUrl = document.getElementById("imageUrl");
    const message = document.getElementById("message");
    const publishButton = document.getElementById("publishButton");

    const editId = new URLSearchParams(location.search).get("edit");

    // Current logged-in user
    let session;

    try {
        session = JSON.parse(
            sessionStorage.getItem("blogspace_demo_session")
        );
    } catch (error) {
        session = null;
    }

    if (!session || !session.userId) {
        message.textContent = "Please login before creating a blog.";
        message.className = "message error";
        form.hidden = true;
        return;
    }

    // Existing edit mode (localStorage)
    const posts = getPosts();

    const existing = editId
        ? posts.find(post => String(post.id) === editId)
        : null;

    if (editId && !existing) {
        message.textContent = "Post not found.";
        message.className = "message error";
        form.hidden = true;
        return;
    }

    if (existing) {
        title.value = existing.title || "";
        description.value = existing.description || "";
        category.value = existing.category || "";
        content.value = existing.content || "";
        imageUrl.value = existing.imageUrl || "";

        document.getElementById("pageTitle").textContent =
            "Edit Blog Post";

        publishButton.textContent = "Save Changes";
    }

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        if (!form.reportValidity()) return;

        const blogData = {
            title: title.value.trim(),
            category: category.value,
            content: content.value.trim(),
            user_id: session.userId
        };

        publishButton.disabled = true;
        publishButton.textContent = "Publishing...";

        try {
            // Send blog to backend
            const response = await fetch(
                "http://localhost:5001/api/blogs/create",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(blogData)
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Blog creation failed.");
            }

            // Save a local copy for the existing dashboard
            const newPost = {
                id: data.blogId,
                title: blogData.title,
                description: description.value.trim(),
                category: blogData.category,
                content: blogData.content,
                imageUrl: imageUrl.value.trim(),
                date: new Date().toISOString()
            };

            const currentPosts = getPosts();
            currentPosts.unshift(newPost);

            if (!savePosts(currentPosts)) {
                throw new Error("Blog saved, but dashboard storage failed.");
            }

            message.textContent = data.message;
            message.className = "message success";

            setTimeout(() => {
                location.href = "dashboard.html";
            }, 1000);

        } catch (error) {
            message.textContent =
                error.message || "Server connection failed.";

            message.className = "message error";

            publishButton.disabled = false;
            publishButton.textContent = "Publish Blog";
        }
    });
}

    // DASHBOARD
    function initializeDashboard() {
        const search = document.getElementById("search");
        const welcome = document.getElementById("welcomeTitle");

        if (search) {
            search.addEventListener("input", renderDashboard);
        }

        if (welcome) {
            try {
                const profile = JSON.parse(
                    localStorage.getItem(PROFILE_KEY)
                );

                if (profile && profile.name) {
                    welcome.textContent = "Welcome, " + profile.name + "!";
                }
            } catch (error) {
                // Keep the default heading.
            }
        }

        renderDashboard();
    }

    return {
        getPosts,
        savePosts,
        initializeHomeSearch,
        renderHomePosts,
        renderDashboard,
        initializePasswordToggle,
        initializeRegistration,
        initializeLogin,
        initializeCreateBlog,
        initializeDashboard
    };
})();

// INITIALIZE PAGE FEATURES
document.addEventListener("DOMContentLoaded", () => {
    BlogSpace.initializePasswordToggle();
    BlogSpace.initializeRegistration();
    BlogSpace.initializeLogin();
    BlogSpace.initializeCreateBlog();
    BlogSpace.initializeDashboard();

    if (document.getElementById("searchInput")) {
        BlogSpace.initializeHomeSearch();
    }
});
